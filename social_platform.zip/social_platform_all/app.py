from flask import Flask, render_template, request, redirect, url_for, session, jsonify, flash
from flask_sqlalchemy import SQLAlchemy
# 在文件顶部确保导入
from flask_socketio import SocketIO, emit, join_room, leave_room
from datetime import datetime
import enum
import os
import uuid
from werkzeug.security import generate_password_hash, check_password_hash
from dotenv import load_dotenv
import logging
from flask_login import current_user
from itsdangerous import URLSafeTimedSerializer
from flask_mail import Mail, Message as MailMessage  # 这里可以给Flask-Mail的Message起别名
import secrets
import string


# 加载环境变量
load_dotenv()

# 初始化 Flask 应用
app = Flask(__name__)
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY')
app.config['SQLALCHEMY_DATABASE_URI'] = os.getenv('DATABASE_URI')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['UPLOAD_FOLDER'] = os.path.join(os.getcwd(), 'static', 'uploads')



# 初始化邮件
app.config['MAIL_SERVER'] = os.getenv('MAIL_SERVER')
app.config['MAIL_PORT'] = int(os.getenv('MAIL_PORT', 587))
app.config['MAIL_USE_TLS'] = os.getenv('MAIL_USE_TLS', 'true').lower() == 'true'
app.config['MAIL_USE_SSL'] = os.getenv('MAIL_USE_SSL', 'false').lower() == 'true'
app.config['MAIL_USERNAME'] = os.getenv('MAIL_USERNAME')
app.config['MAIL_PASSWORD'] = os.getenv('MAIL_PASSWORD')
app.config['MAIL_DEFAULT_SENDER'] = os.getenv('MAIL_DEFAULT_SENDER')
app.config['SECURITY_PASSWORD_SALT'] = os.getenv('SECURITY_PASSWORD_SALT')

mail = Mail(app)


# 创建上传文件夹
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# 初始化数据库和 SocketIO
db = SQLAlchemy(app)
socketio = SocketIO(app, cors_allowed_origins="*")

# -------------------------- 数据库模型定义 --------------------------
class User(db.Model):
    __tablename__ = 'Users'  # 表名与 SQL 一致（首字母大写）
    # 字段定义与之前一致，无需修改
    user_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    first_name = db.Column(db.String(50))
    last_name = db.Column(db.String(50))
    profile_picture_url = db.Column(db.String(255))
    bio = db.Column(db.Text)
    date_of_birth = db.Column(db.Date)
    gender = db.Column(db.Enum('male', 'female', 'other', 'prefer_not_to_say'))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    last_login = db.Column(db.DateTime)
    is_active = db.Column(db.Boolean, default=True)
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
        
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    def get_display_name(self):
    # """获取用户显示名称，优先返回姓+名组合"""
        if self.first_name or self.last_name:
            return f"{self.first_name or ''} {self.last_name or ''}".strip()
        return self.username
    
    def __repr__(self):
        return f"<User {self.get_display_name()}>"

class Friendship(db.Model):
    __tablename__ = 'Friendships'  # 表名与 SQL 一致
    friendship_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user1_id = db.Column(db.Integer, db.ForeignKey('Users.user_id'), nullable=False)  # 外键关联 Users 表
    user2_id = db.Column(db.Integer, db.ForeignKey('Users.user_id'), nullable=False)
    status = db.Column(db.Enum('pending', 'accepted', 'blocked'), default='pending', nullable=False)
    action_user_id = db.Column(db.Integer, db.ForeignKey('Users.user_id'), nullable=False)  # 新增：最后操作用户外键
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # 补充 SQL 中的 CHECK 约束和唯一约束
    __table_args__ = (
        db.CheckConstraint('user1_id < user2_id', name='check_user_order'),  # 与 SQL 约束一致
        db.UniqueConstraint('user1_id', 'user2_id', name='unique_friendship'),  # 避免重复关系
        # 外键删除行为与 SQL 一致（ON DELETE CASCADE）
        {'extend_existing': True}  # 允许表结构扩展（若表已存在）
    )

# class Post(db.Model):
#     __tablename__ = 'Posts'  # 表名与 SQL 一致
#     post_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
#     user_id = db.Column(db.Integer, db.ForeignKey('Users.user_id', ondelete='CASCADE'), nullable=False)  # 补充级联删除
#     content = db.Column(db.Text, nullable=False)
#     media_url = db.Column(db.String(255))
#     media_type = db.Column(db.Enum('image', 'video'), default='image')  # 新增字段
#     privacy_setting = db.Column(db.Enum('public', 'friends', 'private'), default='public')
#     created_at = db.Column(db.DateTime, default=datetime.utcnow)
#     updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
#     user = db.relationship('User', backref=db.backref('posts', lazy=True, cascade='all, delete-orphan'))

class Post(db.Model):
    __tablename__ = 'Posts'
    post_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_id = db.Column(db.Integer, db.ForeignKey('Users.user_id', ondelete='CASCADE'), nullable=False)
    group_id = db.Column(db.Integer, db.ForeignKey('userGroups.group_id', ondelete='CASCADE'), nullable=True)  # 新增群组关联
    content = db.Column(db.Text, nullable=False)
    media_url = db.Column(db.String(255))
    media_type = db.Column(db.Enum('image', 'video'), default='image')
    privacy_setting = db.Column(db.Enum('public', 'friends', 'private', 'group'), default='public')  # 新增group类型
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    user = db.relationship('User', backref=db.backref('posts', lazy=True, cascade='all, delete-orphan'))
    group = db.relationship('Group', backref=db.backref('posts', lazy=True, cascade='all, delete-orphan'))  # 新增关系

class Comment(db.Model):
    __tablename__ = 'Comments'  # 表名与 SQL 一致
    comment_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    post_id = db.Column(db.Integer, db.ForeignKey('Posts.post_id', ondelete='CASCADE'), nullable=False)  # 级联删除
    user_id = db.Column(db.Integer, db.ForeignKey('Users.user_id', ondelete='CASCADE'), nullable=False)
    content = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    user = db.relationship('User', backref=db.backref('comments', lazy=True, cascade='all, delete-orphan'))
    post = db.relationship('Post', backref=db.backref('comments', lazy=True, cascade='all, delete-orphan'))

class PostLike(db.Model):
    __tablename__ = 'PostLikes'
    post_like_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    post_id = db.Column(db.Integer, db.ForeignKey('Posts.post_id', ondelete='CASCADE'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('Users.user_id', ondelete='CASCADE'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    __table_args__ = (
        db.UniqueConstraint('post_id', 'user_id', name='unique_post_like'),
    )
    
    user = db.relationship('User', backref=db.backref('post_likes', lazy=True, cascade='all, delete-orphan'))
    post = db.relationship('Post', backref=db.backref('likes', lazy=True, cascade='all, delete-orphan'))

class CommentLike(db.Model):
    __tablename__ = 'CommentLikes'
    comment_like_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    comment_id = db.Column(db.Integer, db.ForeignKey('Comments.comment_id', ondelete='CASCADE'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('Users.user_id', ondelete='CASCADE'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    __table_args__ = (
        db.UniqueConstraint('comment_id', 'user_id', name='unique_comment_like'),
    )
    
    user = db.relationship('User', backref=db.backref('comment_likes', lazy=True, cascade='all, delete-orphan'))
    comment = db.relationship('Comment', backref=db.backref('likes', lazy=True, cascade='all, delete-orphan'))

class Message(db.Model):
    __tablename__ = 'Messages'  # 表名与 SQL 一致
    message_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    sender_id = db.Column(db.Integer, db.ForeignKey('Users.user_id', ondelete='CASCADE'), nullable=False)
    receiver_id = db.Column(db.Integer, db.ForeignKey('Users.user_id', ondelete='CASCADE'), nullable=False)
    content = db.Column(db.Text, nullable=False)
    is_read = db.Column(db.Boolean, default=False)  # 与 SQL 默认值一致
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    sender = db.relationship('User', foreign_keys=[sender_id], 
                            backref=db.backref('sent_messages', lazy=True, cascade='all, delete-orphan'))
    receiver = db.relationship('User', foreign_keys=[receiver_id],
                              backref=db.backref('received_messages', lazy=True, cascade='all, delete-orphan'))


class Notification(db.Model):
    __tablename__ = 'Notifications'
    notification_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_id = db.Column(db.Integer, db.ForeignKey('Users.user_id', ondelete='CASCADE'), nullable=False)
    # type = db.Column(db.Enum('friend_request', 'friend_request_accepted', 'post_like', 'post_comment', 'comment_like', 'message'), nullable=False)
    type = db.Column(db.Enum('friend_request', 'friend_request_accepted', 'post_like', 'post_comment', 'comment_like', 'message', 'group_post', 'group_invite'), nullable=False)
    related_user_id = db.Column(db.Integer, db.ForeignKey('Users.user_id', ondelete='SET NULL'), nullable=True)
    related_post_id = db.Column(db.Integer, db.ForeignKey('Posts.post_id', ondelete='SET NULL'), nullable=True)
    related_comment_id = db.Column(db.Integer, db.ForeignKey('Comments.comment_id', ondelete='SET NULL'), nullable=True)
    related_message_id = db.Column(db.Integer, db.ForeignKey('Messages.message_id', ondelete='SET NULL'), nullable=True)  # 新增字段
    content = db.Column(db.Text)  # 新增字段
    is_read = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # 添加关系
    related_comment = db.relationship('Comment', foreign_keys=[related_comment_id])
    related_message = db.relationship('Message', foreign_keys=[related_message_id])  # 新增关系

    user = db.relationship('User', foreign_keys=[user_id],
                          backref=db.backref('notifications', lazy=True, cascade='all, delete-orphan'))
    # 新增类型
    related_group_id = db.Column(db.Integer, db.ForeignKey('userGroups.group_id', ondelete='SET NULL'), nullable=True)  # 新增群组关联
    related_group = db.relationship('Group', foreign_keys=[related_group_id])  # 新增关系



class Group(db.Model):
    __tablename__ = 'userGroups'  # 表名与 SQL 一致（而非 Groups）
    group_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)
    creator_id = db.Column(db.Integer, db.ForeignKey('Users.user_id', ondelete='CASCADE'), nullable=False)  # 级联删除
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    creator = db.relationship('User', backref=db.backref('created_groups', lazy=True, cascade='all, delete-orphan'))

class GroupMember(db.Model):
    __tablename__ = 'GroupMembers'  # 表名与 SQL 一致
    group_member_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    group_id = db.Column(db.Integer, db.ForeignKey('userGroups.group_id', ondelete='CASCADE'), nullable=False)  # 外键关联 userGroups
    user_id = db.Column(db.Integer, db.ForeignKey('Users.user_id', ondelete='CASCADE'), nullable=False)
    role = db.Column(db.Enum('admin', 'moderator', 'member'), default='member')
    joined_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # 补充 SQL 中的唯一约束（避免重复加入群组）
    __table_args__ = (
        db.UniqueConstraint('group_id', 'user_id', name='unique_group_member'),
        {'extend_existing': True}
    )
    
    user = db.relationship('User', backref=db.backref('group_memberships', lazy=True, cascade='all, delete-orphan'))
    group = db.relationship('Group', backref=db.backref('members', lazy=True, cascade='all, delete-orphan'))


# -------------------------- 重置密码 --------------------------
# 生成令牌
def generate_token(email):
    serializer = URLSafeTimedSerializer(app.config['SECRET_KEY'])
    return serializer.dumps(email, salt=app.config['SECURITY_PASSWORD_SALT'])

# 验证令牌
def confirm_token(token, expiration=3600):
    serializer = URLSafeTimedSerializer(app.config['SECRET_KEY'])
    try:
        email = serializer.loads(
            token,
            salt=app.config['SECURITY_PASSWORD_SALT'],
            max_age=expiration
        )
        return email
    except Exception:
        return False

# 发送密码重置邮件
def send_reset_email(user_email, token):
    reset_url = url_for('reset_password', token=token, _external=True)
    msg = MailMessage(  # 使用MailMessage而不是Message
        subject="密码重置请求",
        recipients=[user_email],
        body=f'''要重置您的密码，请访问以下链接:
{reset_url}

如果您没有请求重置密码，请忽略此邮件。
'''
    )
    mail.send(msg)


# 生成随机密码
def generate_random_password(length=12):
    characters = string.ascii_letters + string.digits + string.punctuation
    return ''.join(secrets.choice(characters) for _ in range(length))

# -------------------------- 路由实现 --------------------------
# 在app.py中添加
# 添加SocketIO事件处理
@socketio.on('connect')
def handle_connect():
    if 'user_id' in session:
        join_room(str(session['user_id']))  # 将用户加入以其user_id命名的房间
        print(f"用户 {session['user_id']} 已连接")

@socketio.on('disconnect')
def handle_disconnect():
    if 'user_id' in session:
        print(f"用户 {session['user_id']} 已断开")



# 通知发送函数
def send_notification(user_id, notification_data):
    """向指定用户发送实时通知"""
    socketio.emit('new_notification', notification_data, room=str(user_id))


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        
        if User.query.filter_by(username=username).first():
            return "用户名已存在"
        if User.query.filter_by(email=email).first():
            return "邮箱已被注册"
            
        new_user = User(username=username, email=email)
        new_user.set_password(password)
        
        db.session.add(new_user)
        db.session.commit()
        return redirect(url_for('login'))
    
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        user = User.query.filter_by(username=username).first()
        if user and user.check_password(password) and user.is_active:
            user.last_login = datetime.utcnow()
            db.session.commit()
            session['user_id'] = user.user_id
            return redirect(url_for('home'))
        else:
            return "用户名或密码错误"
    
    return render_template('login.html')


# 添加新路由
@app.route('/logout')
def logout():
    session.pop('user_id', None)
    return redirect(url_for('login'))

# 密码重置请求路由
@app.route('/forgot_password', methods=['GET', 'POST'])
def forgot_password():
    if request.method == 'POST':
        email = request.form['email']
        user = User.query.filter_by(email=email).first()
        
        if user:
            token = generate_token(user.email)
            send_reset_email(user.email, token)
            flash('密码重置链接已发送到您的邮箱，请查收。', 'info')
            return redirect(url_for('login'))
        else:
            flash('该邮箱未注册', 'error')
    
    return render_template('forgot_password.html')

# 密码重置路由
@app.route('/reset_password/<token>', methods=['GET', 'POST'])
def reset_password(token):
    email = confirm_token(token)
    if not email:
        flash('重置链接无效或已过期', 'error')
        return redirect(url_for('forgot_password'))
    
    user = User.query.filter_by(email=email).first()
    if not user:
        flash('用户不存在', 'error')
        return redirect(url_for('forgot_password'))
    
    if request.method == 'POST':
        password = request.form['password']
        confirm_password = request.form['confirm_password']
        
        if password != confirm_password:
            flash('两次输入的密码不一致', 'error')
        else:
            user.set_password(password)
            db.session.commit()
            flash('密码已成功重置，请使用新密码登录', 'success')
            return redirect(url_for('login'))
    
    return render_template('reset_password.html', token=token)


@app.route('/create_post', methods=['GET', 'POST'])
def create_post():
    if 'user_id' not in session:
        return redirect(url_for('login'))
        
    if request.method == 'POST':
        content = request.form['content']
        privacy = request.form['privacy']
        media = request.files.get('media')
        
        media_url = None
        media_type = None
        if media and media.filename:
            # 生成唯一文件名
            filename = f"{uuid.uuid4()}_{media.filename}"
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            media.save(filepath)
            media_url = url_for('static', filename=f'uploads/{filename}')
            
            # 判断文件类型
            ext = os.path.splitext(media.filename)[1].lower()
            media_type = 'video' if ext in ['.mp4', '.mov', '.avi'] else 'image'
        
        new_post = Post(
            user_id=session['user_id'],
            content=content,
            media_url=media_url,
            media_type=media_type,  # 新增
            privacy_setting=privacy
        )
        
        db.session.add(new_post)
        db.session.commit()
        return redirect(url_for('home'))
        
    return render_template('create_post.html')

@app.route('/post/<int:post_id>')
@app.route('/post/<int:post_id>/<return_to>/<int:user_id>')
def post_detail(post_id, return_to=None, user_id=None):
    post = Post.query.options(
        db.joinedload(Post.user),
        db.joinedload(Post.comments).joinedload(Comment.user),
        db.joinedload(Post.comments).joinedload(Comment.likes),
        db.joinedload(Post.likes)
    ).get_or_404(post_id)
    
    current_user_id = session.get('user_id')
    is_authenticated = 'user_id' in session
    
    return render_template(
        'post_detail.html', 
        post=post,
        return_to=return_to,
        profile_user_id=user_id,
        in_detail=True,
        current_user_id=current_user_id,
        is_authenticated=is_authenticated  # Add this line
    )


@app.route('/post/<int:post_id>/comment', methods=['POST'])
def add_comment(post_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
        
    post = Post.query.get_or_404(post_id)
    # 添加通知（如果不是自己的帖子）
    if post.user_id != session['user_id']:
        notification = Notification(
            user_id=post.user_id,
            type='post_comment',
            related_user_id=session['user_id'],
            related_post_id=post_id,
            is_read=False
        )
        db.session.add(notification)

    content = request.form['content']
    
    new_comment = Comment(
        post_id=post_id,
        user_id=session['user_id'],
        content=content
    )
    
    db.session.add(new_comment)
    db.session.commit()
    
    # 修改重定向，保留返回路径
    return_to = request.args.get('return_to')
    user_id = request.args.get('user_id')
    if return_to == 'profile' and user_id:
        return redirect(url_for('post_detail', post_id=post_id, return_to=return_to, user_id=user_id))
    return redirect(url_for('post_detail', post_id=post_id))

@app.route('/profile/<int:user_id>')
@app.route('/profile/<int:user_id>/<return_to>')
def profile(user_id, return_to=None):
    user = User.query.get_or_404(user_id)
    
    is_logged_in = 'user_id' in session
    current_user_id = session.get('user_id')
    
    return render_template(
        'profile.html',
        user=user,
        datetime=datetime,
        session=session,
        Friendship=Friendship,
        is_logged_in=is_logged_in,
        current_user_id=current_user_id,
        return_to=return_to,
        request=request  # 传递request对象以获取查询参数
    )



# @app.route('/')
# def home():
#     if 'user_id' not in session:
#         return redirect(url_for('login'))
    
#     # 修改查询方式，使用joinedload预加载关联数据
#     posts = Post.query.filter_by(privacy_setting='public')\
#              .options(
#                  db.joinedload(Post.user),
#                  db.joinedload(Post.likes),
#                  db.joinedload(Post.comments)
#              )\
#              .order_by(Post.created_at.desc())\
#              .all()
    
#     return render_template('home.html', posts=posts)

@app.route('/')
def home():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    # 获取公开帖子和好友帖子
    user_id = session['user_id']
    
    # 获取好友ID列表
    friendships = Friendship.query.filter(
        ((Friendship.user1_id == user_id) | (Friendship.user2_id == user_id)) &
        (Friendship.status == 'accepted')
    ).all()
    
    friend_ids = []
    for fs in friendships:
        if fs.user1_id == user_id:
            friend_ids.append(fs.user2_id)
        else:
            friend_ids.append(fs.user1_id)
    
    # 获取用户加入的群组ID
    group_ids = [gm.group_id for gm in GroupMember.query.filter_by(user_id=user_id).all()]
    
    # 查询帖子：公开的、好友的、或者用户加入的群组的
    posts = Post.query.filter(
        (Post.privacy_setting == 'public') |
        ((Post.privacy_setting == 'friends') & (Post.user_id.in_(friend_ids))) |
        (Post.group_id.in_(group_ids))
    ).options(
        db.joinedload(Post.user),
        db.joinedload(Post.likes),
        db.joinedload(Post.comments),
        db.joinedload(Post.group)  # 新增群组预加载
    ).order_by(Post.created_at.desc()).all()
    
    return render_template('home.html', posts=posts)


# 在app.py中添加以下路由（放在其他路由附近）

@app.route('/profile/edit', methods=['GET', 'POST'])
def edit_profile():
    if 'user_id' not in session:
        return redirect(url_for('login'))
        
    user = User.query.get_or_404(session['user_id'])
    
    if request.method == 'POST':
        # 处理表单提交
        user.first_name = request.form.get('first_name')
        user.last_name = request.form.get('last_name')
        user.bio = request.form.get('bio')
        user.gender = request.form.get('gender')
        
        # 处理日期格式
        dob_str = request.form.get('date_of_birth')
        if dob_str:
            try:
                user.date_of_birth = datetime.strptime(dob_str, '%Y-%m-%d').date()
            except ValueError:
                pass  # 保持原值
        
        # 处理头像上传
        profile_pic = request.files.get('profile_picture')
        if profile_pic and profile_pic.filename:
            # 生成唯一文件名
            filename = f"{uuid.uuid4()}_{profile_pic.filename}"
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            profile_pic.save(filepath)
            user.profile_picture_url = url_for('static', filename=f'uploads/{filename}')
        
        db.session.commit()
        return redirect(url_for('profile', user_id=user.user_id))
    
    return render_template('edit_profile.html', user=user)

# 在app.py中添加以下路由（放在其他路由附近）

# 好友关系管理路由
@app.route('/friends')
def friends():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    user_id = session['user_id']
    # 获取好友请求（待处理的）
    pending_requests = Friendship.query.filter(
        ((Friendship.user1_id == user_id) | (Friendship.user2_id == user_id)) &
        (Friendship.status == 'pending') &
        (Friendship.action_user_id != user_id)
    ).all()

    # 获取已接受的好友
    accepted_friendships = Friendship.query.filter(
        ((Friendship.user1_id == user_id) | (Friendship.user2_id == user_id)) &
        (Friendship.status == 'accepted')
    ).all()
    
    # 获取当前用户的好友列表
    friends = []
    for fs in accepted_friendships:
        if fs.user1_id == user_id:
            friend = User.query.get(fs.user2_id)
        else:
            friend = User.query.get(fs.user1_id)
        friends.append(friend)
    
    return render_template('friends.html', 
                         pending_requests=pending_requests,
                         friends=friends,
                         User=User)  # 添加这一行传递User模型

# 发送好友请求
@app.route('/friend_request/<int:friend_id>')
def send_friend_request(friend_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    user_id = session['user_id']
    
    # 确保user1_id总是小于user2_id
    user1_id, user2_id = sorted([user_id, friend_id])
    
    # 检查是否已经是好友或已有请求
    existing = Friendship.query.filter_by(
        user1_id=user1_id, user2_id=user2_id).first()
    
    if existing:
        if existing.status == 'accepted':
            return "已经是好友"
        elif existing.status == 'pending':
            return "好友请求已发送"
        elif existing.status == 'blocked':
            return "该用户已被屏蔽"
    else:
        # 创建新的好友请求
        new_request = Friendship(
            user1_id=user1_id,
            user2_id=user2_id,
            status='pending',
            action_user_id=user_id
        )
        db.session.add(new_request)
        db.session.commit()
        
        # 创建通知
        notification = Notification(
            user_id=friend_id,
            type='friend_request',
            related_user_id=user_id,
            is_read=False
        )
        db.session.add(notification)
        db.session.commit()
        # 实时推送
        current_user = User.query.get(user_id)
        send_notification(friend_id, {
            'type': 'friend_request',
            'message': f'{current_user.username} 发送了好友请求',
            'related_user_id': user_id
        })
        
        return redirect(url_for('profile', user_id=friend_id))

# 处理好友请求
@app.route('/handle_friend_request/<int:friendship_id>/<action>')
def handle_friend_request(friendship_id, action):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    friendship = Friendship.query.get_or_404(friendship_id)
    user_id = session['user_id']
    
    # 确保当前用户是被请求方
    if user_id not in [friendship.user1_id, friendship.user2_id]:
        return "无权操作"
    
    if friendship.action_user_id == user_id:
        return "不能操作自己发起的请求"
    
    if action == 'accept':
        friendship.status = 'accepted'
        friendship.action_user_id = user_id
        db.session.commit()
        
        # 创建通知
        other_user = friendship.user1_id if friendship.user2_id == user_id else friendship.user2_id
        notification = Notification(
            user_id=other_user,
            type='friend_request_accepted',
            related_user_id=user_id,
            is_read=False
        )
        db.session.add(notification)
        db.session.commit()
        
    elif action == 'reject':
        db.session.delete(friendship)
        db.session.commit()
    elif action == 'block':
        friendship.status = 'blocked'
        friendship.action_user_id = user_id
        db.session.commit()
    
    return redirect(url_for('friends'))


# @app.route('/notifications')
# def notifications():
#     if 'user_id' not in session:
#         return redirect(url_for('login'))
    
#     user_id = session['user_id']
#     notifications = Notification.query.filter_by(user_id=user_id) \
#         .order_by(Notification.created_at.desc()) \
#         .all()
    
#     # 标记为已读
#     for notification in notifications:
#         notification.is_read = True
#     db.session.commit()
    
#     # 提前查询所有相关用户信息
#     related_user_ids = set()
#     for n in notifications:
#         if n.related_user_id:
#             related_user_ids.add(n.related_user_id)

#     related_users = {u.user_id: u for u in User.query.filter(User.user_id.in_(related_user_ids)).all()}
    
#     return render_template(
#         'notifications.html', 
#         notifications=notifications,
#         related_users=related_users,
#         Friendship=Friendship,
#         min=min,
#         max=max
#     )

@app.route('/notifications')
def notifications():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    user_id = session['user_id']
    notifications = Notification.query.filter_by(user_id=user_id) \
        .order_by(Notification.created_at.desc()) \
        .all()
    
    # 标记为已读
    for notification in notifications:
        notification.is_read = True
    db.session.commit()
    
    # 提前查询所有相关用户、群组等信息
    related_user_ids = set()
    related_group_ids = set()
    for n in notifications:
        if n.related_user_id:
            related_user_ids.add(n.related_user_id)
        if n.related_group_id:
            related_group_ids.add(n.related_group_id)

    related_users = {u.user_id: u for u in User.query.filter(User.user_id.in_(related_user_ids)).all()}
    related_groups = {g.group_id: g for g in Group.query.filter(Group.group_id.in_(related_group_ids)).all()}
    
    return render_template(
        'notifications.html', 
        notifications=notifications,
        related_users=related_users,
        related_groups=related_groups,
        Friendship=Friendship,
        min=min,
        max=max
    )

# 添加通知计数API
@app.route('/api/notifications/count')
def notification_count():
    if 'user_id' not in session:
        return jsonify({'count': 0})
    
    count = Notification.query.filter_by(
        user_id=session['user_id'],
        is_read=False
    ).count()
    
    return jsonify({'count': count})


@app.route('/post/<int:post_id>/like', methods=['POST'])
def like_post(post_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    post = Post.query.get_or_404(post_id)
    user_id = session['user_id']
    
    # 检查是否已经点赞
    existing_like = PostLike.query.filter_by(post_id=post_id, user_id=user_id).first()
    
    if existing_like:
        # 如果已经点赞，则取消点赞
        db.session.delete(existing_like)
        db.session.commit()
    else:
        # 添加点赞
        new_like = PostLike(post_id=post_id, user_id=user_id)
        db.session.add(new_like)
        
        # 添加通知（如果不是自己的帖子）
        if post.user_id != user_id:
            notification = Notification(
                user_id=post.user_id,
                type='post_like',
                related_user_id=user_id,
                related_post_id=post_id,
                is_read=False
            )
            db.session.add(notification)
        
        db.session.commit()
    
    return redirect(url_for('post_detail', post_id=post_id))


@app.route('/comment/<int:comment_id>/like', methods=['POST'])
def like_comment(comment_id):
    logging.info(f"Like comment request for comment_id: {comment_id}")
    if 'user_id' not in session:
        logging.warning("User not logged in")
        return jsonify({'success': False, 'error': '未登录'})
    
    comment = Comment.query.get_or_404(comment_id)
    logging.info(f"Found comment: {comment.comment_id} by user: {comment.user_id}")
    
    user_id = session['user_id']
    logging.info(f"Current user: {user_id}")
    # ... rest of the function
    
    existing_like = CommentLike.query.filter_by(
        comment_id=comment_id, 
        user_id=user_id
    ).first()
    
    if existing_like:
        db.session.delete(existing_like)
        action = 'unlike'
    else:
        new_like = CommentLike(comment_id=comment_id, user_id=user_id)
        db.session.add(new_like)
        action = 'like'
        
        # 添加通知（如果不是自己的评论）
        if comment.user_id != user_id:
            notification = Notification(
                user_id=comment.user_id,
                type='comment_like',
                related_user_id=user_id,
                related_comment_id=comment_id,
                is_read=False
            )
            db.session.add(notification)
            
            # 实时推送通知
            current_user = User.query.get(user_id)
            send_notification(comment.user_id, {
                'type': 'comment_like',
                'message': f'{current_user.username} 点赞了您的评论',
                'related_user_id': user_id,
                'related_comment_id': comment_id
            })
    
    db.session.commit()  # 只保留这一个提交
    
    return jsonify({
        'success': True,
        'action': action,
        'like_count': CommentLike.query.filter_by(comment_id=comment_id).count()
    })
    


# @app.route('/send_message', methods=['POST'])
# def send_message():
#     if 'user_id' not in session:
#         return jsonify({'success': False, 'error': '未登录'})
    
#     receiver_id = request.form.get('receiver_id')
#     content = request.form.get('content')
    
#     if not receiver_id or not content:
#         return jsonify({'success': False, 'error': '参数不完整'})
    
#     # 检查是否为好友关系
#     user1_id, user2_id = sorted([session['user_id'], int(receiver_id)])
#     friendship = Friendship.query.filter_by(
#         user1_id=user1_id,
#         user2_id=user2_id,
#         status='accepted'
#     ).first()
    
#     if not friendship:
#         return jsonify({'success': False, 'error': '只能给好友发送消息'})
    
#     new_message = Message(
#         sender_id=session['user_id'],
#         receiver_id=receiver_id,
#         content=content
#     )
    
#     db.session.add(new_message)
#     db.session.commit()  # 必须先提交才能获取message_id
    
#     # 创建通知
#     sender = User.query.get(session['user_id'])
#     notification = Notification(
#         user_id=receiver_id,
#         type='message',
#         related_user_id=session['user_id'],
#         is_read=False,
#         content=f"您收到来自{sender.username}的消息: {content[:50]}",  # 存储消息内容
#         related_message_id=new_message.message_id  # 添加相关消息ID
#     )
#     db.session.add(notification)
    
#     db.session.commit()
    
#     # 实时通知
#     socketio.emit('new_message', {
#         'sender_id': session['user_id'],
#         'receiver_id': receiver_id,
#         'content': content,
#         'created_at': datetime.utcnow().isoformat()
#     }, room=str(receiver_id))
    
#     return jsonify({
#         'success': True,
#         'message': {
#             'message_id': new_message.message_id,
#             'sender_id': new_message.sender_id,
#             'content': new_message.content,
#             'created_at': new_message.created_at.isoformat()
#         }
#     })

@app.route('/send_message', methods=['POST'])
def send_message():
    if 'user_id' not in session:
        return jsonify({'success': False, 'error': '未登录'})
    
    receiver_id = request.form.get('receiver_id')
    content = request.form.get('content')
    
    if not receiver_id or not content:
        return jsonify({'success': False, 'error': '参数不完整'})
    
    # 检查是否为好友关系
    user1_id, user2_id = sorted([session['user_id'], int(receiver_id)])
    friendship = Friendship.query.filter_by(
        user1_id=user1_id,
        user2_id=user2_id,
        status='accepted'
    ).first()
    
    if not friendship:
        return jsonify({'success': False, 'error': '只能给好友发送消息'})
    
    new_message = Message(
        sender_id=session['user_id'],
        receiver_id=receiver_id,
        content=content
    )
    
    db.session.add(new_message)
    db.session.commit()  # 必须先提交才能获取message_id
    
    # 创建通知
    sender = User.query.get(session['user_id'])
    notification = Notification(
        user_id=receiver_id,
        type='message',
        related_user_id=session['user_id'],
        is_read=False,
        content=f"您收到来自{sender.get_display_name()}的消息: {content[:50]}",
        related_message_id=new_message.message_id
    )
    db.session.add(notification)
    
    db.session.commit()
    
    # 实时通知
    socketio.emit('new_message', {
        'message_id': new_message.message_id,
        'sender_id': session['user_id'],
        'receiver_id': receiver_id,
        'content': content,
        'is_read': False,  # 新消息初始为未读
        'created_at': datetime.utcnow().isoformat()
    }, room=str(receiver_id))
    
    return jsonify({
        'success': True,
        'message': {
            'message_id': new_message.message_id,
            'sender_id': new_message.sender_id,
            'content': new_message.content,
            'is_read': new_message.is_read,
            'created_at': new_message.created_at.isoformat()
        }
    })


@app.route('/get_messages/<int:friend_id>')
def get_messages(friend_id):
    if 'user_id' not in session:
        return jsonify({'success': False, 'error': '未登录'})
    
    # 标记所有未读消息为已读
    Message.query.filter_by(
        sender_id=friend_id,
        receiver_id=session['user_id'],
        is_read=False
    ).update({'is_read': True})
    db.session.commit()
    
    # 获取消息列表
    messages = Message.query.filter(
        ((Message.sender_id == session['user_id']) & (Message.receiver_id == friend_id)) |
        ((Message.sender_id == friend_id) & (Message.receiver_id == session['user_id']))
    ).order_by(Message.created_at).all()
    
    return jsonify({
        'success': True,
        'messages': [{
            'id': m.message_id,
            'sender_id': m.sender_id,
            'content': m.content,
            'is_read': m.is_read,
            'created_at': m.created_at.isoformat()
        } for m in messages]
    })



@app.route('/chat/<int:friend_id>')
def chat_with_friend(friend_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    # 验证好友关系
    user1_id, user2_id = sorted([session['user_id'], friend_id])
    friendship = Friendship.query.filter_by(
        user1_id=user1_id,
        user2_id=user2_id,
        status='accepted'
    ).first()
    
    if not friendship:
        return redirect(url_for('friends'))
    
    # 获取消息ID参数并标记为已读
    msg_id = request.args.get('msg_id')
    if msg_id:
        Message.query.filter_by(
            message_id=msg_id,
            receiver_id=session['user_id'],
            is_read=False
        ).update({'is_read': True})
        db.session.commit()
    
    friend = User.query.get(friend_id)
    messages = Message.query.filter(
        ((Message.sender_id == session['user_id']) & (Message.receiver_id == friend_id)) |
        ((Message.sender_id == friend_id) & (Message.receiver_id == session['user_id']))
    ).order_by(Message.created_at).all()
    
    return render_template('chat.html', friend=friend, messages=messages)

@socketio.on('join_chat')
def handle_join_chat(data):
    if 'user_id' in session:
        join_room(f"chat_{session['user_id']}_{data['friend_id']}")
        emit('status', {'message': 'Joined chat room'})

@socketio.on('leave_chat')
def handle_leave_chat(data):
    if 'user_id' in session:
        leave_room(f"chat_{session['user_id']}_{data['friend_id']}")

@socketio.on('mark_messages_as_read')
def handle_mark_messages_as_read(data):
    if 'user_id' not in session:
        return
    
    user_id = session['user_id']
    friend_id = data['friend_id']
    
    # 标记所有来自对方的消息为已读
    Message.query.filter_by(
        sender_id=friend_id,
        receiver_id=user_id,
        is_read=False
    ).update({'is_read': True})
    db.session.commit()
    
    # 通知对方哪些消息已被阅读
    unread_messages = Message.query.filter(
        Message.sender_id == user_id,
        Message.receiver_id == friend_id,
        Message.is_read == True
    ).all()
    
    for msg in unread_messages:
        emit('message_read', {
            'message_id': msg.message_id,
            'is_read': True
        }, room=str(friend_id))


# -------------------------- 群组路由 --------------------------

@app.route('/groups')
def groups():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    # 获取用户加入的所有群组
    user_groups = GroupMember.query.filter_by(user_id=session['user_id']).all()
    group_ids = [gm.group_id for gm in user_groups]
    
    # 获取这些群组的详细信息
    groups = Group.query.filter(Group.group_id.in_(group_ids)).all()
    
    # 获取所有公开群组（用户未加入的）
    public_groups = Group.query.filter(~Group.group_id.in_(group_ids)).all()
    
    return render_template('groups.html', 
                         my_groups=groups,
                         public_groups=public_groups)

@app.route('/group/create', methods=['GET', 'POST'])
def create_group():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    if request.method == 'POST':
        name = request.form['name']
        description = request.form.get('description', '')
        
        new_group = Group(
            name=name,
            description=description,
            creator_id=session['user_id']
        )
        db.session.add(new_group)
        db.session.commit()
        
        # 创建者自动成为管理员
        admin_member = GroupMember(
            group_id=new_group.group_id,
            user_id=session['user_id'],
            role='admin'
        )
        db.session.add(admin_member)
        db.session.commit()
        
        return redirect(url_for('group_detail', group_id=new_group.group_id))
    
    return render_template('create_group.html')

@app.route('/group/<int:group_id>')
def group_detail(group_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    group = Group.query.options(
        db.joinedload(Group.creator),
        db.joinedload(Group.members).joinedload(GroupMember.user)
    ).get_or_404(group_id)
    
    # 检查当前用户是否是成员
    is_member = GroupMember.query.filter_by(
        group_id=group_id,
        user_id=session['user_id']
    ).first() is not None
    
    # 检查当前用户是否是管理员或版主
    is_admin_or_moderator = GroupMember.query.filter_by(
        group_id=group_id,
        user_id=session['user_id'],
        role=db.or_(GroupMember.role == 'admin', GroupMember.role == 'moderator')
    ).first() is not None
    
    # 获取群组成员
    members = GroupMember.query.filter_by(group_id=group_id).all()
    
    # 获取群组帖子
    posts = Post.query.filter_by(group_id=group_id).order_by(Post.created_at.desc()).all()
    
    return render_template(
        'group_detail.html',
        group=group,
        is_member=is_member,
        is_admin_or_moderator=is_admin_or_moderator,  # 新增
        members=members,
        posts=posts,
        GroupMember=GroupMember  # 传递GroupMember模型到模板
    )

@app.route('/group/<int:group_id>/join')
def join_group(group_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    # 检查是否已经是成员
    existing_member = GroupMember.query.filter_by(
        group_id=group_id,
        user_id=session['user_id']
    ).first()
    
    if existing_member:
        return redirect(url_for('group_detail', group_id=group_id))
    
    new_member = GroupMember(
        group_id=group_id,
        user_id=session['user_id'],
        role='member'
    )
    db.session.add(new_member)
    db.session.commit()
    
    return redirect(url_for('group_detail', group_id=group_id))

@app.route('/group/<int:group_id>/leave')
def leave_group(group_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    member = GroupMember.query.filter_by(
        group_id=group_id,
        user_id=session['user_id']
    ).first()
    
    if member:
        db.session.delete(member)
        db.session.commit()
    
    return redirect(url_for('groups'))

@app.route('/group/<int:group_id>/create_post', methods=['GET', 'POST'])
def create_group_post(group_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    # 检查用户是否是群组成员
    is_member = GroupMember.query.filter_by(
        group_id=group_id,
        user_id=session['user_id']
    ).first() is not None
    
    if not is_member:
        return redirect(url_for('group_detail', group_id=group_id))
    
    if request.method == 'POST':
        content = request.form['content']
        media = request.files.get('media')
        
        media_url = None
        media_type = None
        if media and media.filename:
            filename = f"{uuid.uuid4()}_{media.filename}"
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            media.save(filepath)
            media_url = url_for('static', filename=f'uploads/{filename}')
            
            ext = os.path.splitext(media.filename)[1].lower()
            media_type = 'video' if ext in ['.mp4', '.mov', '.avi'] else 'image'
        
        new_post = Post(
            user_id=session['user_id'],
            content=content,
            media_url=media_url,
            media_type=media_type,
            privacy_setting='group',
            group_id=group_id
        )
        
        db.session.add(new_post)
        db.session.flush()  # 获取新帖子的ID
        
        # 创建群组通知
        members = GroupMember.query.filter_by(group_id=group_id).all()
        for member in members:
            if member.user_id != session['user_id']:
                notification = Notification(
                    user_id=member.user_id,
                    type='group_post',  # 使用正确的通知类型
                    related_user_id=session['user_id'],
                    related_post_id=new_post.post_id,
                    related_group_id=group_id,  # 设置群组ID
                    content=f"新群组帖子: {content[:50]}",
                    is_read=False
                )
                db.session.add(notification)
        
        db.session.commit()
        return redirect(url_for('group_detail', group_id=group_id))
    
    return render_template('create_group_post.html', group_id=group_id)

@app.route('/group/<int:group_id>/manage', methods=['GET', 'POST'])
def manage_group(group_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    # 检查用户是否是群组管理员
    member = GroupMember.query.filter_by(
        group_id=group_id,
        user_id=session['user_id']
    ).first()
    
    if not member or member.role not in ['admin', 'moderator']:
        return redirect(url_for('group_detail', group_id=group_id))
    
    group = Group.query.get_or_404(group_id)
    
    if request.method == 'POST':
        group.name = request.form['name']
        group.description = request.form.get('description', '')
        db.session.commit()
        return redirect(url_for('group_detail', group_id=group_id))
    
    members = GroupMember.query.filter_by(group_id=group_id).all()
    
    return render_template('manage_group.html',
                         group=group,
                         members=members)

@app.route('/group/<int:group_id>/change_role/<int:user_id>', methods=['POST'])
def change_member_role(group_id, user_id):
    if 'user_id' not in session:
        return jsonify({'success': False, 'error': '未登录'})
    
    # 检查当前用户是否有权限
    current_member = GroupMember.query.filter_by(
        group_id=group_id,
        user_id=session['user_id']
    ).first()
    
    if not current_member or current_member.role not in ['admin', 'moderator']:
        return jsonify({'success': False, 'error': '无权操作'})
    
    target_member = GroupMember.query.filter_by(
        group_id=group_id,
        user_id=user_id
    ).first()
    
    if not target_member:
        return jsonify({'success': False, 'error': '成员不存在'})
    
    new_role = request.form.get('role')
    if new_role not in ['admin', 'moderator', 'member']:
        return jsonify({'success': False, 'error': '无效角色'})
    
    # 确保至少有一个管理员
    if target_member.role == 'admin' and new_role != 'admin':
        admin_count = GroupMember.query.filter_by(
            group_id=group_id,
            role='admin'
        ).count()
        if admin_count <= 1:
            return jsonify({'success': False, 'error': '群组必须至少有一个管理员'})
    
    target_member.role = new_role
    db.session.commit()
    
    return jsonify({'success': True})

@app.route('/group/<int:group_id>/remove_member/<int:user_id>', methods=['POST'])
def remove_group_member(group_id, user_id):
    if 'user_id' not in session:
        return jsonify({'success': False, 'error': '未登录'})
    
    # 检查当前用户是否有权限
    current_member = GroupMember.query.filter_by(
        group_id=group_id,
        user_id=session['user_id']
    ).first()
    
    if not current_member or current_member.role not in ['admin', 'moderator']:
        return jsonify({'success': False, 'error': '无权操作'})
    
    # 不能移除自己
    if user_id == session['user_id']:
        return jsonify({'success': False, 'error': '不能移除自己'})
    
    target_member = GroupMember.query.filter_by(
        group_id=group_id,
        user_id=user_id
    ).first()
    
    if not target_member:
        return jsonify({'success': False, 'error': '成员不存在'})
    
    # 确保至少有一个管理员
    if target_member.role == 'admin':
        admin_count = GroupMember.query.filter_by(
            group_id=group_id,
            role='admin'
        ).count()
        if admin_count <= 1:
            return jsonify({'success': False, 'error': '群组必须至少有一个管理员'})

    db.session.delete(target_member)
    db.session.commit()
    
    return jsonify({'success': True})

@socketio.on('join_group')
def handle_join_group(data):
    if 'user_id' in session:
        group_id = data.get('group_id')
        if group_id:
            join_room(f"group_{group_id}")
            emit('status', {'message': f'Joined group room {group_id}'})

@socketio.on('leave_group')
def handle_leave_group(data):
    if 'user_id' in session:
        group_id = data.get('group_id')
        if group_id:
            leave_room(f"group_{group_id}")
            emit('status', {'message': f'Left group room {group_id}'})

# @app.context_processor
# def utility_processor():
#     def display_name(user):
#         if user.first_name or user.last_name:
#             return f"{user.first_name} {user.last_name}".strip()
#         return user.username
#     return dict(display_name=display_name)

@app.context_processor
def utility_processor():
    def display_name(user):
        """模板中使用的显示名称函数"""
        return user.get_display_name()
    return dict(display_name=display_name)

# 补充其他路由（发布内容、点赞、评论、好友管理等）...


# -------------------------- 启动应用 --------------------------
# if __name__ == '__main__':
#     socketio.run(app, debug=True)
if __name__ == '__main__':
    socketio.run(app, host='0.0.0.0', port=5000, debug=True)